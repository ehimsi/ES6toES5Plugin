import sublime, sublime_plugin,os
from os.path import dirname, realpath

class BuildonSave(sublime_plugin.EventListener):

  def on_post_save(self, view):
    es6File = view.file_name()
    filename, file_extension = os.path.splitext(es6File)
    if file_extension == ".es6":
      view.window().run_command('exec',{'cmd': ["C:\\Users\\hijoshi\\AppData\\Roaming\\npm\\babel.cmd", es6File, "-o", filename+".js"] })
